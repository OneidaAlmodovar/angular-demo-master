export const AppConfig = {
  appUrl: 'https://example.form.io',
  apiUrl: 'https://api.form.io'
};
